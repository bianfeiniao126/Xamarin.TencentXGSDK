//
//  AppDelegate.h
//  XG-Demo
//
//  Created by xiangchen on 13-11-6.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
