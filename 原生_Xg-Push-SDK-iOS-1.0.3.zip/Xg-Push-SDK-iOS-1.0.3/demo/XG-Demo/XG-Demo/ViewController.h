//
//  ViewController.h
//  XG-Demo
//
//  Created by xiangchen on 13-11-6.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIButton *btnSetTag;
    IBOutlet UIButton *btnDelTag;
    
    IBOutlet UIButton *btnSetAlias;
    IBOutlet UIButton *btnDelAlias;
    
    IBOutlet UILabel *lblTest;
    IBOutlet UIButton *btnLogoutDevice;
}

- (IBAction)setTag:(id)sender;
- (IBAction)delTag:(id)sender;

- (IBAction)setAlias:(id)sender;
- (IBAction)delAlias:(id)sender;

- (IBAction)logoutDevice:(id)sender;
@end
